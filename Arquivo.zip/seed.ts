import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Criando instância da tabela `Funcionario`
  const funcionario1 = await prisma.funcionario.create({
    data: {
      nomeFunc: 'João Silva',
      cpfFunc: '12345678901',
      dataNasc: new Date('1990-01-01'),
      salario: 2500,
      tipo: 'MOTORISTA',
      
    },
  })

  const funcionario2 = await prisma.funcionario.create({
    data: {
      nomeFunc: 'Maria Oliveira',
      cpfFunc: '10987654321',
      dataNasc: new Date('1985-05-15'),
      salario: 3000,
      tipo: 'MOTORISTA',
    },
  })

  // Criando instância da tabela `Motorista`
  

  // Criando instância da tabela `Transportadora`
  const transportadora = await prisma.transportadora.create({
    data: {
      nomeTransp: 'Transportadora XYZ',
      cnpjTransp: '12.345.678/0001-99',
      enderecoTransp: 'Rua das Transportadoras, 123',
    },
  })

  // Criando instância da tabela `Veiculo`
  const veiculo1 = await prisma.veiculo.create({
    data: {
      renav: 123456789,
      placa: 'ABC1234',
      modelo: 'Furgão',
      marca: 'Ford',
      ano: 2015,
      capacidade: 2000,
    },
  })

  const veiculo2 = await prisma.veiculo.create({
    data: {
      renav: 987654321,
      placa: 'XYZ9876',
      modelo: 'Caminhão',
      marca: 'Mercedes',
      ano: 2020,
      capacidade: 5000,
    },
  })

  // Criando instância da tabela `Local`
  const local1 = await prisma.local.create({
    data: {
      endereco: 'Rua A, 123',
      tipoImovel: 'Armazém',
      custoMensal: 1500,
      tipo: 'Armazém',
    },
  })

  const local2 = await prisma.local.create({
    data: {
      endereco: 'Rua B, 456',
      tipoImovel: 'Escritório',
      custoMensal: 3500,
      tipo: 'Escritório',
    },
  })

  // Criando instância da tabela `Fornecedor`
  const fornecedor = await prisma.fornecedor.create({
    data: {
      nomeFor: 'Fornecedor ABC',
      cnpjFor: '98.765.432/0001-01',
      comissao: 15,
      endereco: 'Rua do Fornecedor, 789',
      tipo: 'Fornecedor de Material',
    },
  })

  // Criando instância da tabela `NotaFiscal`
  const notaFiscal = await prisma.notaFiscal.create({
    data: {
      numNota: 12345,
      peso: 1000,
      cidade: 'São Paulo',
      numItens: 10,
    },
  })

  // Criando instância da tabela `Relatorio`
  const relatorio = await prisma.relatorio.create({
    data: {
      dataInicio: new Date('2025-01-01'),
      dataFinal: new Date('2025-01-31'),
    },
  })

  // Criando instância da tabela `Entrega`
  const entrega = await prisma.entrega.create({
    data: {
      cidadeDestino: 'Rio de Janeiro',
      quilometragem: 500,
      status: 'Em andamento',
      dataSaida: new Date('2025-05-07'),
    },
  })

  console.log('Todas as instâncias foram criadas com sucesso!')
}

main()
  .catch(e => {
    throw e
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
